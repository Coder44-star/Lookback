#include "LookbackOption.h"
#include <iostream>
#include <iomanip>
#include <fstream>

void printResults(const OptionResults& results, const MarketData& market) {
    std::cout << "\n========================================" << std::endl;
    std::cout << "   RÉSULTATS DU PRICING LOOKBACK" << std::endl;
    std::cout << "========================================\n" << std::endl;
    
    std::cout << "Paramètres de marché:" << std::endl;
    std::cout << "  Type d'option: " << Utils::optionTypeToString(market.type) << std::endl;
    std::cout << "  Prix spot (S0): " << std::fixed << std::setprecision(2) << market.S0 << std::endl;
    std::cout << "  Taux sans risque (r): " << std::setprecision(4) << market.r * 100 << "%" << std::endl;
    std::cout << "  Volatilité (σ): " << market.sigma * 100 << "%" << std::endl;
    std::cout << "  Maturité (T): " << std::setprecision(4) << market.T << " ans" << std::endl;
    
    std::cout << "\nRésultats du pricing:" << std::endl;
    std::cout << "  Prix de l'option: " << std::setprecision(4) << results.price << std::endl;
    std::cout << "  Erreur standard: " << std::setprecision(6) << results.stdError << std::endl;
    
    std::cout << "\nGrecs de l'option:" << std::endl;
    std::cout << "  Delta (∂P/∂S): " << std::setprecision(6) << results.delta << std::endl;
    std::cout << "  Gamma (∂²P/∂S²): " << std::setprecision(8) << results.gamma << std::endl;
    std::cout << "  Theta (∂P/∂t): " << std::setprecision(6) << results.theta << std::endl;
    std::cout << "  Rho (∂P/∂r): " << std::setprecision(6) << results.rho << std::endl;
    std::cout << "  Vega (∂P/∂σ): " << std::setprecision(6) << results.vega << std::endl;
    
    std::cout << "\n========================================\n" << std::endl;
}

void exportToCSV(const std::string& filename, 
                 const std::vector<std::pair<double, double>>& data,
                 const std::string& header1,
                 const std::string& header2) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Erreur: Impossible d'ouvrir le fichier " << filename << std::endl;
        return;
    }
    
    file << header1 << "," << header2 << "\n";
    for (const auto& point : data) {
        file << std::fixed << std::setprecision(6) << point.first << "," << point.second << "\n";
    }
    file.close();
    std::cout << "Données exportées vers " << filename << std::endl;
}

int main() {
    try {
        // Configuration des paramètres de marché
        MarketData market;
        market.S0 = 100.0;           // Prix spot
        market.r = 0.05;             // Taux sans risque 5%
        market.sigma = 0.25;         // Volatilité 25%
        market.T = 1.0;              // Maturité 1 an
        market.type = OptionType::CALL;
        
        // Configuration Monte-Carlo
        MonteCarloParams mcParams;
        mcParams.numSimulations = 50000;  // Nombre de simulations
        mcParams.numSteps = 252;          // Nombre de pas (jours de trading)
        mcParams.seed = 12345;            // Graine aléatoire
        
        std::cout << "\n**************************************************" << std::endl;
        std::cout << "  PRICER D'OPTIONS LOOKBACK PAR MONTE-CARLO" << std::endl;
        std::cout << "**************************************************\n" << std::endl;
        
        // Création du pricer
        LookbackOptionPricer pricer(market, mcParams);
        
        // Calcul du prix et des Greeks
        std::cout << "Démarrage des calculs...\n" << std::endl;
        OptionResults results = pricer.price();
        
        // Affichage des résultats
        printResults(results, market);
        
        // Génération des graphiques
        std::cout << "\nGénération des données pour les graphiques..." << std::endl;
        
        // Graphique Prix vs Spot (de 70 à 130)
        std::cout << "\nCalcul du prix en fonction du spot..." << std::endl;
        auto priceData = pricer.priceVsSpot(70.0, 130.0, 20);
        exportToCSV("price_vs_spot.csv", priceData, "Spot_Price", "Option_Price");
        
        // Graphique Delta vs Spot
        std::cout << "\nCalcul du Delta en fonction du spot..." << std::endl;
        auto deltaData = pricer.deltaVsSpot(70.0, 130.0, 20);
        exportToCSV("delta_vs_spot.csv", deltaData, "Spot_Price", "Delta");
        
        std::cout << "\n**************************************************" << std::endl;
        std::cout << "  CALCULS TERMINÉS AVEC SUCCÈS!" << std::endl;
        std::cout << "**************************************************\n" << std::endl;
        
        // Test avec un PUT
        std::cout << "\n=== Test avec un PUT Lookback ===" << std::endl;
        market.type = OptionType::PUT;
        LookbackOptionPricer putPricer(market, mcParams);
        OptionResults putResults = putPricer.price();
        printResults(putResults, market);
        
    } catch (const std::exception& e) {
        std::cerr << "\nERREUR: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}
