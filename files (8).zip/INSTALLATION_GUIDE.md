# Guide d'Installation et Configuration Excel

## Étape 1: Compilation de la DLL

### Sous Windows avec MinGW-w64

1. **Installer MinGW-w64**
   - Télécharger depuis: https://www.mingw-w64.org/
   - Ou installer via MSYS2: https://www.msys2.org/

2. **Compiler la DLL**
   ```bash
   # Ouvrir un terminal MinGW
   cd C:\Users\VotreNom\Desktop\LookbackPricer
   
   # Compilation
   g++ -std=c++17 -O3 -fopenmp -shared -DBUILDING_DLL ^
       -o LookbackPricer.dll ^
       LookbackOption.cpp ExcelWrapper.cpp
   ```

3. **Vérifier la DLL**
   ```bash
   # La DLL doit faire environ 50-100 KB
   dir LookbackPricer.dll
   ```

### Sous Windows avec Visual Studio

1. **Créer un nouveau projet DLL**
   - Ouvrir Visual Studio
   - Fichier > Nouveau > Projet
   - Sélectionner "Bibliothèque de liens dynamiques (DLL)"

2. **Ajouter les fichiers**
   - Ajouter `LookbackOption.h`, `LookbackOption.cpp`
   - Ajouter `ExcelWrapper.h`, `ExcelWrapper.cpp`

3. **Configuration du projet**
   - Propriétés du projet > C/C++ > Langage > Standard du langage C++ : C++17
   - Propriétés du projet > C/C++ > Optimisation > Optimisation : Vitesse maximale (/O2)
   - Propriétés du projet > C/C++ > Préprocesseur > Définitions : Ajouter `BUILDING_DLL`

4. **Compiler**
   - Génération > Générer la solution
   - La DLL sera dans le dossier `x64\Release\`

## Étape 2: Configuration d'Excel

### A. Activation des macros

1. **Ouvrir Excel**
2. **Fichier > Options > Centre de gestion de la confidentialité**
3. **Paramètres du Centre de gestion de la confidentialité**
4. **Paramètres des macros**
5. Sélectionner: **"Activer toutes les macros"**
6. Cocher: **"Faire confiance à l'accès au modèle d'objet du projet VBA"**

### B. Afficher l'onglet Développeur

1. **Fichier > Options > Personnaliser le ruban**
2. Cocher **"Développeur"** dans la liste de droite
3. Cliquer sur **OK**

### C. Importer le module VBA

1. **Développeur > Visual Basic** (ou Alt+F11)
2. **Insertion > Module**
3. Copier-coller le contenu de `ExcelVBA_Module.bas`
4. **Modifier le chemin de la DLL** à la ligne 17:
   ```vba
   Private Declare PtrSafe Function PriceLookbackOption Lib "C:\Chemin\Vers\LookbackPricer.dll" ...
   ```
   Remplacer par le chemin réel de votre DLL

## Étape 3: Création de la feuille Excel

### A. Structure de base

Créer une feuille avec la structure suivante:

```
     A                    B              C    D                  E
1    PRICER D'OPTIONS LOOKBACK
2    Type d'option:       CALL                Prix de l'option:  [Résultat]
3    Prix Spot (S0):      100                 Delta:             [Résultat]
4    Taux sans risque:    0.05                Gamma:             [Résultat]
5    Volatilité (σ):      0.25                Theta:             [Résultat]
6    Maturité (T):        1                   Rho:               [Résultat]
7    Nb simulations:      50000               Vega:              [Résultat]
8    Nb pas de temps:     252                 Erreur standard:   [Résultat]
```

### B. Validation des données

Pour la cellule B2 (Type d'option):
1. Sélectionner B2
2. **Données > Validation des données**
3. Autoriser: **Liste**
4. Source: `CALL,PUT`

### C. Format des nombres

- B4 (Taux): Format Pourcentage (0.00%)
- B5 (Volatilité): Format Pourcentage (0.00%)
- E2 (Prix): Format Nombre (0.0000)
- E3-E7 (Greeks): Format Nombre (0.000000)

### D. Ajout des boutons

1. **Développeur > Insérer > Bouton (Contrôle de formulaire)**
2. Dessiner un bouton
3. Dans la boîte de dialogue, sélectionner la macro **CalculerOptionLookback**
4. Renommer le bouton: "Calculer Option"
5. Répéter pour créer un second bouton avec la macro **GenererGraphiquePrix**
6. Renommer: "Générer Graphique"

## Étape 4: Test de l'installation

### Test 1: Fonction Excel simple

Dans une cellule vide, taper:
```
=LOOKBACK_PRICE("CALL", 100, 0.05, 0.25, 1)
```

Résultat attendu: ~20.0 (avec variations Monte-Carlo)

### Test 2: Calcul complet avec bouton

1. Vérifier que les paramètres en B2:B8 sont remplis
2. Cliquer sur le bouton **"Calculer Option"**
3. Attendre 10-30 secondes
4. Les résultats doivent apparaître en E2:E8

### Test 3: Génération de graphique

1. Cliquer sur le bouton **"Générer Graphique"**
2. Attendre 30-60 secondes
3. Un graphique doit apparaître montrant Prix vs Spot

## Étape 5: Utilisation avancée

### Formules Excel personnalisées

```excel
' Prix d'un Call Lookback
=LOOKBACK_PRICE("CALL", B3, B4, B5, B6, B7, B8)

' Prix d'un Put Lookback
=LOOKBACK_PRICE("PUT", B3, B4, B5, B6, B7, B8)

' Delta
=LOOKBACK_DELTA("CALL", B3, B4, B5, B6, B7, B8)
```

### Tableau de sensibilité

Créer un tableau pour analyser l'impact de différents paramètres:

```
Prix Spot    50     75     100    125    150
Prix Call    [=]    [=]    [=]    [=]    [=]
Delta        [=]    [=]    [=]    [=]    [=]
```

Utiliser les formules avec références absolues et relatives.

### Analyse de scénarios

Créer différents scénarios avec le Gestionnaire de scénarios d'Excel:
- Scénario optimiste (volatilité faible, spot élevé)
- Scénario neutre
- Scénario pessimiste (volatilité élevée, spot faible)

## Dépannage

### Problème: "Impossible de trouver la DLL"

**Solution:**
1. Vérifier que le chemin dans le code VBA est correct
2. Vérifier que la DLL est bien compilée (existe dans le dossier)
3. Essayer de mettre la DLL dans `C:\Windows\System32\`

### Problème: "Erreur d'exécution 49: DLL incorrecte"

**Solution:**
1. Vérifier la version Excel (32-bit vs 64-bit)
2. Recompiler la DLL pour la bonne architecture:
   ```bash
   # Pour 32-bit
   g++ -m32 -std=c++17 -O3 -shared -DBUILDING_DLL ...
   
   # Pour 64-bit
   g++ -m64 -std=c++17 -O3 -shared -DBUILDING_DLL ...
   ```

### Problème: Calculs très lents

**Solutions:**
1. Réduire le nombre de simulations (B7) à 30000 ou 20000
2. Réduire le nombre de pas (B8) à 100
3. S'assurer que OpenMP est activé lors de la compilation
4. Vérifier l'utilisation CPU dans le Gestionnaire des tâches

### Problème: Résultats qui varient beaucoup

**Explication:** C'est normal avec Monte-Carlo. Pour réduire la variance:
1. Augmenter le nombre de simulations
2. Utiliser une graine fixe pour des résultats reproductibles
3. L'erreur standard (E8) indique la précision

### Problème: Excel plante lors du calcul

**Solutions:**
1. Réduire drastiquement le nombre de simulations (ex: 10000)
2. Vérifier la RAM disponible
3. Fermer les autres applications
4. Compiler sans optimisations agressives (-O1 au lieu de -O3)

## Performance attendue

### Configuration typique
- CPU: Intel Core i5/i7 ou AMD Ryzen 5/7
- RAM: 8 GB minimum
- Système: Windows 10/11 64-bit

### Temps de calcul

| Opération              | Nb simulations | Temps estimé |
|------------------------|----------------|--------------|
| Prix seul              | 50,000         | 2-3 sec      |
| Prix seul              | 100,000        | 4-6 sec      |
| Tous les Greeks        | 50,000         | 20-40 sec    |
| Graphique (20 points)  | 30,000         | 30-60 sec    |

## Fichiers requis

```
LookbackPricer/
├── LookbackOption.h          # Header principal
├── LookbackOption.cpp        # Implémentation
├── ExcelWrapper.h            # Wrapper DLL
├── ExcelWrapper.cpp          # Implémentation wrapper
├── LookbackPricer.dll        # DLL compilée (Windows)
├── ExcelVBA_Module.bas       # Code VBA
└── Template_Lookback.xlsm    # Fichier Excel (à créer)
```

## Support et contact

Pour les problèmes techniques:
1. Vérifier le README.md
2. Consulter les références bibliographiques
3. Contacter les auteurs du projet

**Auteurs:** Pedro Ferreira & Vincent Torri  
**Date:** 18 novembre 2025  
**Cours:** M2 Ingénierie et Finance
