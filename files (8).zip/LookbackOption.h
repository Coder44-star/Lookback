#ifndef LOOKBACK_OPTION_H
#define LOOKBACK_OPTION_H

#include <vector>
#include <string>
#include <cmath>
#include <random>
#include <algorithm>
#include <numeric>

// Énumération pour le type d'option
enum class OptionType {
    CALL,
    PUT
};

// Structure pour les paramètres de marché
struct MarketData {
    double S0;           // Prix initial du sous-jacent
    double r;            // Taux sans risque
    double sigma;        // Volatilité
    double T;            // Maturité en années
    OptionType type;     // Type d'option (Call ou Put)
};

// Structure pour les paramètres Monte-Carlo
struct MonteCarloParams {
    int numSimulations;  // Nombre de simulations
    int numSteps;        // Nombre de pas de temps
    unsigned int seed;   // Graine pour le générateur aléatoire
    
    MonteCarloParams(int sims = 100000, int steps = 252, unsigned int s = 42)
        : numSimulations(sims), numSteps(steps), seed(s) {}
};

// Structure pour les résultats (Greeks)
struct OptionResults {
    double price;        // Prix de l'option
    double delta;        // ∂P/∂S
    double gamma;        // ∂²P/∂S²
    double theta;        // ∂P/∂t
    double rho;          // ∂P/∂r
    double vega;         // ∂P/∂σ
    double stdError;     // Erreur standard du prix
    
    OptionResults() : price(0.0), delta(0.0), gamma(0.0), 
                      theta(0.0), rho(0.0), vega(0.0), stdError(0.0) {}
};

// Classe principale pour le pricing des options lookback
class LookbackOptionPricer {
private:
    MarketData market;
    MonteCarloParams mcParams;
    std::mt19937 rng;
    std::normal_distribution<double> normalDist;
    
    // Méthode privée pour simuler un chemin du sous-jacent
    std::vector<double> simulatePath();
    
    // Calcul du payoff pour un chemin donné
    double calculatePayoff(const std::vector<double>& path);
    
    // Calcul du prix par Monte-Carlo
    double computePrice(double& stdError);
    
    // Méthode des différences finies pour les Greeks
    double computeDelta();
    double computeGamma();
    double computeTheta();
    double computeRho();
    double computeVega();

public:
    // Constructeur
    LookbackOptionPricer(const MarketData& mkt, const MonteCarloParams& mc);
    
    // Méthode principale de calcul
    OptionResults price();
    
    // Méthodes pour calculer le prix en fonction de S pour les graphiques
    std::vector<std::pair<double, double>> priceVsSpot(double Smin, double Smax, int numPoints);
    
    // Méthodes pour calculer le Delta en fonction de S pour les graphiques
    std::vector<std::pair<double, double>> deltaVsSpot(double Smin, double Smax, int numPoints);
    
    // Getters
    const MarketData& getMarketData() const { return market; }
    const MonteCarloParams& getMCParams() const { return mcParams; }
    
    // Setters
    void setSpotPrice(double S) { market.S0 = S; }
    void setVolatility(double vol) { market.sigma = vol; }
    void setRiskFreeRate(double rate) { market.r = rate; }
    void setMaturity(double maturity) { market.T = maturity; }
};

// Fonctions utilitaires
namespace Utils {
    // Conversion de string vers OptionType
    OptionType stringToOptionType(const std::string& type);
    
    // Conversion de OptionType vers string
    std::string optionTypeToString(OptionType type);
    
    // Calcul de la date en années à partir d'aujourd'hui
    double yearsToMaturity(int days);
}

#endif // LOOKBACK_OPTION_H
