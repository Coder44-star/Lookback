#include "ExcelWrapper.h"
#include "LookbackOption.h"
#include <string>
#include <cstring>

// ========== Fonction principale de pricing ==========
double PriceLookbackOption(
    const char* optionType,
    double spotPrice,
    double strikePrice,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed
) {
    try {
        MarketData market;
        market.S0 = spotPrice;
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        double stdErr;
        return pricer.computePrice(stdErr);
    } catch (...) {
        return -999999.0; // Erreur
    }
}

// ========== Calcul du Delta ==========
double CalculateDelta(
    const char* optionType,
    double spotPrice,
    double strikePrice,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed
) {
    try {
        MarketData market;
        market.S0 = spotPrice;
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        return pricer.computeDelta();
    } catch (...) {
        return -999999.0;
    }
}

// ========== Calcul du Gamma ==========
double CalculateGamma(
    const char* optionType,
    double spotPrice,
    double strikePrice,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed
) {
    try {
        MarketData market;
        market.S0 = spotPrice;
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        return pricer.computeGamma();
    } catch (...) {
        return -999999.0;
    }
}

// ========== Calcul du Theta ==========
double CalculateTheta(
    const char* optionType,
    double spotPrice,
    double strikePrice,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed
) {
    try {
        MarketData market;
        market.S0 = spotPrice;
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        return pricer.computeTheta();
    } catch (...) {
        return -999999.0;
    }
}

// ========== Calcul du Rho ==========
double CalculateRho(
    const char* optionType,
    double spotPrice,
    double strikePrice,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed
) {
    try {
        MarketData market;
        market.S0 = spotPrice;
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        return pricer.computeRho();
    } catch (...) {
        return -999999.0;
    }
}

// ========== Calcul du Vega ==========
double CalculateVega(
    const char* optionType,
    double spotPrice,
    double strikePrice,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed
) {
    try {
        MarketData market;
        market.S0 = spotPrice;
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        return pricer.computeVega();
    } catch (...) {
        return -999999.0;
    }
}

// ========== Calcul de tous les Greeks en une fois ==========
void CalculateAllGreeks(
    const char* optionType,
    double spotPrice,
    double strikePrice,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed,
    double* outPrice,
    double* outDelta,
    double* outGamma,
    double* outTheta,
    double* outRho,
    double* outVega,
    double* outStdError
) {
    try {
        MarketData market;
        market.S0 = spotPrice;
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        OptionResults results = pricer.price();
        
        *outPrice = results.price;
        *outDelta = results.delta;
        *outGamma = results.gamma;
        *outTheta = results.theta;
        *outRho = results.rho;
        *outVega = results.vega;
        *outStdError = results.stdError;
    } catch (...) {
        *outPrice = -999999.0;
        *outDelta = -999999.0;
        *outGamma = -999999.0;
        *outTheta = -999999.0;
        *outRho = -999999.0;
        *outVega = -999999.0;
        *outStdError = -999999.0;
    }
}

// ========== Génération de données pour graphique Prix vs Spot ==========
void GeneratePriceVsSpot(
    const char* optionType,
    double spotMin,
    double spotMax,
    int numPoints,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed,
    double* outSpotPrices,
    double* outOptionPrices
) {
    try {
        MarketData market;
        market.S0 = spotMin; // Valeur initiale, sera modifiée
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        auto results = pricer.priceVsSpot(spotMin, spotMax, numPoints);
        
        for (int i = 0; i < numPoints; ++i) {
            outSpotPrices[i] = results[i].first;
            outOptionPrices[i] = results[i].second;
        }
    } catch (...) {
        for (int i = 0; i < numPoints; ++i) {
            outSpotPrices[i] = -999999.0;
            outOptionPrices[i] = -999999.0;
        }
    }
}

// ========== Génération de données pour graphique Delta vs Spot ==========
void GenerateDeltaVsSpot(
    const char* optionType,
    double spotMin,
    double spotMax,
    int numPoints,
    double riskFreeRate,
    double volatility,
    double timeToMaturity,
    int numSimulations,
    int numSteps,
    unsigned int seed,
    double* outSpotPrices,
    double* outDeltas
) {
    try {
        MarketData market;
        market.S0 = spotMin;
        market.r = riskFreeRate;
        market.sigma = volatility;
        market.T = timeToMaturity;
        market.type = Utils::stringToOptionType(std::string(optionType));
        
        MonteCarloParams mcParams(numSimulations, numSteps, seed);
        
        LookbackOptionPricer pricer(market, mcParams);
        auto results = pricer.deltaVsSpot(spotMin, spotMax, numPoints);
        
        for (int i = 0; i < numPoints; ++i) {
            outSpotPrices[i] = results[i].first;
            outDeltas[i] = results[i].second;
        }
    } catch (...) {
        for (int i = 0; i < numPoints; ++i) {
            outSpotPrices[i] = -999999.0;
            outDeltas[i] = -999999.0;
        }
    }
}
