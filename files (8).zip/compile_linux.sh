#!/bin/bash
# Script de compilation pour Linux/Mac
# Utilise g++ ou clang++

set -e  # Arrêt en cas d'erreur

echo "================================================"
echo "  COMPILATION DU PRICER D'OPTIONS LOOKBACK"
echo "================================================"
echo ""

# Vérification du compilateur
if ! command -v g++ &> /dev/null; then
    echo "ERREUR: g++ n'est pas installé"
    echo "Installation:"
    echo "  - Ubuntu/Debian: sudo apt-get install g++"
    echo "  - MacOS: xcode-select --install"
    exit 1
fi

echo "[1/3] Compilation de l'exécutable standalone..."
g++ -std=c++17 -O3 -Wall -Wextra -fopenmp \
    -o lookback_pricer \
    LookbackOption.cpp main.cpp

if [ $? -ne 0 ]; then
    echo "ERREUR lors de la compilation de l'exécutable"
    exit 1
fi
echo "✓ OK: lookback_pricer créé"

echo ""
echo "[2/3] Compilation de la bibliothèque partagée..."
g++ -std=c++17 -O3 -Wall -Wextra -fopenmp \
    -shared -fPIC \
    -o LookbackPricer.so \
    LookbackOption.cpp ExcelWrapper.cpp

if [ $? -ne 0 ]; then
    echo "ERREUR lors de la compilation de la bibliothèque"
    exit 1
fi
echo "✓ OK: LookbackPricer.so créée"

echo ""
echo "[3/3] Test de l'exécutable..."
./lookback_pricer

if [ $? -ne 0 ]; then
    echo "ERREUR lors de l'exécution du test"
    exit 1
fi

echo ""
echo "================================================"
echo "  COMPILATION TERMINÉE AVEC SUCCÈS!"
echo "================================================"
echo ""
echo "Fichiers générés:"
echo "  - lookback_pricer     : Programme de test"
echo "  - LookbackPricer.so   : Bibliothèque partagée"
echo "  - price_vs_spot.csv   : Données graphique prix"
echo "  - delta_vs_spot.csv   : Données graphique delta"
echo ""
echo "Pour utiliser avec Excel (via Wine ou LibreOffice):"
echo "  1. Installer Wine (Windows sur Linux)"
echo "  2. Compiler la DLL Windows avec MinGW:"
echo "     x86_64-w64-mingw32-g++ -shared -o LookbackPricer.dll ..."
echo ""
echo "Pour tester:"
echo "  ./lookback_pricer"
echo ""
