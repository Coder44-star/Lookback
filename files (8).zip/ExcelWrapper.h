#ifndef EXCEL_WRAPPER_H
#define EXCEL_WRAPPER_H

#ifdef _WIN32
    #ifdef BUILDING_DLL
        #define DLL_EXPORT __declspec(dllexport)
    #else
        #define DLL_EXPORT __declspec(dllimport)
    #endif
#else
    #define DLL_EXPORT
#endif

extern "C" {
    // Fonction principale pour pricer une option lookback
    DLL_EXPORT double PriceLookbackOption(
        const char* optionType,     // "CALL" ou "PUT"
        double spotPrice,           // S0
        double strikePrice,         // K (non utilisé pour lookback standard)
        double riskFreeRate,        // r
        double volatility,          // sigma
        double timeToMaturity,      // T en années
        int numSimulations,         // Nombre de simulations MC
        int numSteps,               // Nombre de pas de temps
        unsigned int seed           // Graine aléatoire
    );
    
    // Calcul du Delta
    DLL_EXPORT double CalculateDelta(
        const char* optionType,
        double spotPrice,
        double strikePrice,
        double riskFreeRate,
        double volatility,
        double timeToMaturity,
        int numSimulations,
        int numSteps,
        unsigned int seed
    );
    
    // Calcul du Gamma
    DLL_EXPORT double CalculateGamma(
        const char* optionType,
        double spotPrice,
        double strikePrice,
        double riskFreeRate,
        double volatility,
        double timeToMaturity,
        int numSimulations,
        int numSteps,
        unsigned int seed
    );
    
    // Calcul du Theta
    DLL_EXPORT double CalculateTheta(
        const char* optionType,
        double spotPrice,
        double strikePrice,
        double riskFreeRate,
        double volatility,
        double timeToMaturity,
        int numSimulations,
        int numSteps,
        unsigned int seed
    );
    
    // Calcul du Rho
    DLL_EXPORT double CalculateRho(
        const char* optionType,
        double spotPrice,
        double strikePrice,
        double riskFreeRate,
        double volatility,
        double timeToMaturity,
        int numSimulations,
        int numSteps,
        unsigned int seed
    );
    
    // Calcul du Vega
    DLL_EXPORT double CalculateVega(
        const char* optionType,
        double spotPrice,
        double strikePrice,
        double riskFreeRate,
        double volatility,
        double timeToMaturity,
        int numSimulations,
        int numSteps,
        unsigned int seed
    );
    
    // Calcul de tous les Greeks en une fois (plus efficace)
    DLL_EXPORT void CalculateAllGreeks(
        const char* optionType,
        double spotPrice,
        double strikePrice,
        double riskFreeRate,
        double volatility,
        double timeToMaturity,
        int numSimulations,
        int numSteps,
        unsigned int seed,
        double* outPrice,
        double* outDelta,
        double* outGamma,
        double* outTheta,
        double* outRho,
        double* outVega,
        double* outStdError
    );
    
    // Génération de données pour graphique Prix vs Spot
    DLL_EXPORT void GeneratePriceVsSpot(
        const char* optionType,
        double spotMin,
        double spotMax,
        int numPoints,
        double riskFreeRate,
        double volatility,
        double timeToMaturity,
        int numSimulations,
        int numSteps,
        unsigned int seed,
        double* outSpotPrices,
        double* outOptionPrices
    );
    
    // Génération de données pour graphique Delta vs Spot
    DLL_EXPORT void GenerateDeltaVsSpot(
        const char* optionType,
        double spotMin,
        double spotMax,
        int numPoints,
        double riskFreeRate,
        double volatility,
        double timeToMaturity,
        int numSimulations,
        int numSteps,
        unsigned int seed,
        double* outSpotPrices,
        double* outDeltas
    );
}

#endif // EXCEL_WRAPPER_H
