# Pricer d'Options Lookback par Monte-Carlo

## Description

Ce projet implémente un pricer d'options lookback européennes utilisant la méthode de Monte-Carlo dans le cadre du modèle de Black-Scholes. Il a été développé pour le cours M2 Ingénierie et Finance.

### Types d'options supportées

**Call Lookback**: Paye la différence entre le prix du sous-jacent à maturité et son minimum sur la période:
```
Payoff = S(T) - min[T0≤t≤T] S(t)
```

**Put Lookback**: Paye la différence entre le maximum du sous-jacent et son prix à maturité:
```
Payoff = max[T0≤t≤T] S(t) - S(T)
```

## Caractéristiques

✅ **Pricing Monte-Carlo** avec méthode de simulation de chemins  
✅ **Calcul des Greeks** (Delta, Gamma, Theta, Rho, Vega) par différences finies  
✅ **Génération de graphiques** Prix vs Spot et Delta vs Spot  
✅ **Interface Excel** via DLL/SO  
✅ **Performance optimisée** avec OpenMP pour parallélisation  
✅ **Erreur standard** calculée pour chaque prix  

## Structure du projet

```
project_C__/
├── LookbackOption.h      # Header principal avec classes et structures
├── LookbackOption.cpp    # Implémentation du pricer
├── ExcelWrapper.h        # Header pour l'interface Excel
├── ExcelWrapper.cpp      # Wrapper pour appels depuis Excel
├── main.cpp              # Programme de test standalone
├── Makefile              # Compilation automatisée
└── README.md             # Cette documentation
```

## Compilation

### Prérequis
- Compilateur C++ supportant C++17 (g++, clang++, MSVC)
- OpenMP pour la parallélisation (optionnel mais recommandé)

### Linux/Mac
```bash
# Compilation de l'exécutable standalone
make

# Compilation de la bibliothèque partagée pour Excel
make so

# Test du programme
make test

# Nettoyage
make clean
```

### Windows (MinGW)
```bash
# Compilation de l'exécutable
g++ -std=c++17 -O3 -fopenmp -o lookback_pricer.exe LookbackOption.cpp main.cpp

# Compilation de la DLL pour Excel
g++ -std=c++17 -O3 -fopenmp -shared -DBUILDING_DLL -o LookbackPricer.dll LookbackOption.cpp ExcelWrapper.cpp
```

### Windows (Visual Studio)
```bash
cl /EHsc /O2 /openmp /std:c++17 LookbackOption.cpp main.cpp /Fe:lookback_pricer.exe

# Pour la DLL
cl /EHsc /O2 /openmp /std:c++17 /LD /DBUILDING_DLL LookbackOption.cpp ExcelWrapper.cpp /Fe:LookbackPricer.dll
```

## Utilisation

### Programme standalone

```cpp
#include "LookbackOption.h"

// Configuration des paramètres de marché
MarketData market;
market.S0 = 100.0;           // Prix spot
market.r = 0.05;             // Taux sans risque (5%)
market.sigma = 0.25;         // Volatilité (25%)
market.T = 1.0;              // Maturité (1 an)
market.type = OptionType::CALL;

// Configuration Monte-Carlo
MonteCarloParams mcParams;
mcParams.numSimulations = 100000;
mcParams.numSteps = 252;
mcParams.seed = 42;

// Création du pricer et calcul
LookbackOptionPricer pricer(market, mcParams);
OptionResults results = pricer.price();

// Affichage des résultats
std::cout << "Prix: " << results.price << std::endl;
std::cout << "Delta: " << results.delta << std::endl;
std::cout << "Gamma: " << results.gamma << std::endl;
```

### Intégration Excel (VBA)

#### 1. Déclaration des fonctions dans VBA

```vba
' Module VBA pour l'interface avec la DLL C++

' Déclaration des fonctions de la DLL
Private Declare PtrSafe Function PriceLookbackOption Lib "C:\Path\To\LookbackPricer.dll" ( _
    ByVal optionType As String, _
    ByVal spotPrice As Double, _
    ByVal strikePrice As Double, _
    ByVal riskFreeRate As Double, _
    ByVal volatility As Double, _
    ByVal timeToMaturity As Double, _
    ByVal numSimulations As Long, _
    ByVal numSteps As Long, _
    ByVal seed As Long) As Double

Private Declare PtrSafe Sub CalculateAllGreeks Lib "C:\Path\To\LookbackPricer.dll" ( _
    ByVal optionType As String, _
    ByVal spotPrice As Double, _
    ByVal strikePrice As Double, _
    ByVal riskFreeRate As Double, _
    ByVal volatility As Double, _
    ByVal timeToMaturity As Double, _
    ByVal numSimulations As Long, _
    ByVal numSteps As Long, _
    ByVal seed As Long, _
    ByRef outPrice As Double, _
    ByRef outDelta As Double, _
    ByRef outGamma As Double, _
    ByRef outTheta As Double, _
    ByRef outRho As Double, _
    ByRef outVega As Double, _
    ByRef outStdError As Double)
```

#### 2. Fonctions Excel personnalisées

```vba
' Fonction pour calculer le prix
Function LOOKBACK_PRICE(optionType As String, S0 As Double, r As Double, _
                        sigma As Double, T As Double, _
                        Optional numSim As Long = 50000, _
                        Optional numSteps As Long = 252) As Double
    LOOKBACK_PRICE = PriceLookbackOption(optionType, S0, 0, r, sigma, T, _
                                         numSim, numSteps, 42)
End Function

' Fonction pour calculer tous les Greeks
Sub CALCULATE_GREEKS(optionType As String, S0 As Double, r As Double, _
                     sigma As Double, T As Double, _
                     resultRange As Range, _
                     Optional numSim As Long = 50000, _
                     Optional numSteps As Long = 252)
    
    Dim price As Double, delta As Double, gamma As Double
    Dim theta As Double, rho As Double, vega As Double, stdErr As Double
    
    Call CalculateAllGreeks(optionType, S0, 0, r, sigma, T, _
                           numSim, numSteps, 42, _
                           price, delta, gamma, theta, rho, vega, stdErr)
    
    ' Écrire les résultats dans Excel
    resultRange.Cells(1, 1).Value = "Prix"
    resultRange.Cells(1, 2).Value = price
    resultRange.Cells(2, 1).Value = "Delta"
    resultRange.Cells(2, 2).Value = delta
    resultRange.Cells(3, 1).Value = "Gamma"
    resultRange.Cells(3, 2).Value = gamma
    resultRange.Cells(4, 1).Value = "Theta"
    resultRange.Cells(4, 2).Value = theta
    resultRange.Cells(5, 1).Value = "Rho"
    resultRange.Cells(5, 2).Value = rho
    resultRange.Cells(6, 1).Value = "Vega"
    resultRange.Cells(6, 2).Value = vega
    resultRange.Cells(7, 1).Value = "Erreur Std"
    resultRange.Cells(7, 2).Value = stdErr
End Sub
```

#### 3. Utilisation dans Excel

Dans une cellule Excel:
```
=LOOKBACK_PRICE("CALL", 100, 0.05, 0.25, 1, 50000, 252)
```

Ou via bouton VBA:
```vba
Sub CalculerOption()
    Dim optType As String
    Dim S0 As Double, r As Double, sigma As Double, T As Double
    
    ' Lire les paramètres depuis les cellules
    optType = Range("B2").Value    ' "CALL" ou "PUT"
    S0 = Range("B3").Value         ' Prix spot
    r = Range("B4").Value          ' Taux sans risque
    sigma = Range("B5").Value      ' Volatilité
    T = Range("B6").Value          ' Maturité
    
    ' Calculer et afficher les résultats
    Call CALCULATE_GREEKS(optType, S0, r, sigma, T, Range("D2:E8"))
End Sub
```

## Paramètres d'entrée

| Paramètre | Description | Type | Exemple |
|-----------|-------------|------|---------|
| optionType | Type d'option | String | "CALL" ou "PUT" |
| S0 | Prix spot du sous-jacent | Double | 100.0 |
| r | Taux sans risque (annuel) | Double | 0.05 (5%) |
| σ | Volatilité (annuelle) | Double | 0.25 (25%) |
| T | Maturité en années | Double | 1.0 |
| numSimulations | Nombre de simulations MC | Integer | 50000 |
| numSteps | Nombre de pas de temps | Integer | 252 |
| seed | Graine aléatoire | Integer | 42 |

## Sorties calculées

| Sortie | Description | Formule |
|--------|-------------|---------|
| **Prix (P)** | Prix théorique de l'option | E[e^(-rT) × Payoff] |
| **Delta (Δ)** | Sensibilité au prix spot | ∂P/∂S |
| **Gamma (Γ)** | Convexité | ∂²P/∂S² |
| **Theta (Θ)** | Décroissance temporelle | ∂P/∂t |
| **Rho (ρ)** | Sensibilité au taux | ∂P/∂r |
| **Vega (ν)** | Sensibilité à la volatilité | ∂P/∂σ |

## Optimisations et performances

### Parallélisation
Le code utilise OpenMP pour paralléliser les simulations Monte-Carlo:
```cpp
#pragma omp parallel for if(mcParams.numSimulations > 10000)
for (int i = 0; i < mcParams.numSimulations; ++i) {
    // Simulation parallèle
}
```

### Recommandations
- **Nombre de simulations**: 50,000 - 100,000 pour un bon compromis vitesse/précision
- **Nombre de pas**: 252 (jours de trading) est un bon choix standard
- **Threads OpenMP**: Ajuster selon le nombre de cœurs disponibles

### Temps d'exécution typiques (i7, 4 cores)
- 50,000 simulations: ~2-3 secondes
- 100,000 simulations: ~4-6 secondes
- Calcul complet avec Greeks: ~30-60 secondes

## Méthode numérique

### Simulation de Monte-Carlo
Pour chaque simulation, on génère un chemin du sous-jacent suivant:
```
S(t+Δt) = S(t) × exp((r - σ²/2)Δt + σ√Δt × Z)
```
où Z ~ N(0,1)

### Calcul des Greeks
Les Greeks sont calculés par différences finies:
- **Delta**: (P(S+h) - P(S-h)) / (2h)
- **Gamma**: (P(S+h) - 2P(S) + P(S-h)) / h²
- **Theta**: (P(T-h) - P(T)) / h
- **Rho**: (P(r+h) - P(r-h)) / (2h)
- **Vega**: (P(σ+h) - P(σ-h)) / (2h)

## Validation

Le code peut être validé contre:
1. Simulations avec paramètres connus
2. Propriétés de parité Put-Call pour options lookback
3. Limites asymptotiques (T→0, σ→0)

## Références

1. John Hull, *Options, Futures and Other Derivatives*, Pearson, 2011
2. Paul Wilmott, *Mathematics of Financial Derivatives*, Wiley, 1995
3. Paul Glasserman, *Monte Carlo Methods in Financial Engineering*, Springer, 2003
4. Gilles Pagès, *Numerical Probability*, Springer, 2018
5. Emmanuel Gobet, *Monte-Carlo Methods and Stochastic Processes*, CRC Press, 2016

## Auteurs

Pedro Ferreira & Vincent Torri  
M2 Ingénierie et Finance  
18 novembre 2025

## Licence

Ce projet est développé dans un cadre académique pour le cours M2 Ingénierie et Finance.
