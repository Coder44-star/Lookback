#include "LookbackOption.h"
#include <iostream>
#include <iomanip>
#include <ctime>

// ========== Constructeur ==========
LookbackOptionPricer::LookbackOptionPricer(const MarketData& mkt, const MonteCarloParams& mc)
    : market(mkt), mcParams(mc), rng(mc.seed), normalDist(0.0, 1.0) {
    // Validation des paramètres
    if (market.S0 <= 0.0) throw std::invalid_argument("Le prix spot doit être positif");
    if (market.sigma <= 0.0) throw std::invalid_argument("La volatilité doit être positive");
    if (market.T <= 0.0) throw std::invalid_argument("La maturité doit être positive");
    if (mcParams.numSimulations <= 0) throw std::invalid_argument("Le nombre de simulations doit être positif");
    if (mcParams.numSteps <= 0) throw std::invalid_argument("Le nombre de pas doit être positif");
}

// ========== Simulation d'un chemin ==========
std::vector<double> LookbackOptionPricer::simulatePath() {
    std::vector<double> path(mcParams.numSteps + 1);
    path[0] = market.S0;
    
    double dt = market.T / mcParams.numSteps;
    double drift = (market.r - 0.5 * market.sigma * market.sigma) * dt;
    double diffusion = market.sigma * std::sqrt(dt);
    
    for (int i = 1; i <= mcParams.numSteps; ++i) {
        double Z = normalDist(rng);
        path[i] = path[i-1] * std::exp(drift + diffusion * Z);
    }
    
    return path;
}

// ========== Calcul du payoff ==========
double LookbackOptionPricer::calculatePayoff(const std::vector<double>& path) {
    double finalPrice = path.back();
    
    if (market.type == OptionType::CALL) {
        // Call lookback: S(T) - min(S(t))
        double minPrice = *std::min_element(path.begin(), path.end());
        return std::max(0.0, finalPrice - minPrice);
    } else {
        // Put lookback: max(S(t)) - S(T)
        double maxPrice = *std::max_element(path.begin(), path.end());
        return std::max(0.0, maxPrice - finalPrice);
    }
}

// ========== Calcul du prix par Monte-Carlo ==========
double LookbackOptionPricer::computePrice(double& stdError) {
    std::vector<double> payoffs(mcParams.numSimulations);
    
    // Simulations parallélisables
    #pragma omp parallel for if(mcParams.numSimulations > 10000)
    for (int i = 0; i < mcParams.numSimulations; ++i) {
        std::vector<double> path = simulatePath();
        payoffs[i] = calculatePayoff(path);
    }
    
    // Calcul de la moyenne et de l'erreur standard
    double sum = std::accumulate(payoffs.begin(), payoffs.end(), 0.0);
    double mean = sum / mcParams.numSimulations;
    
    // Calcul de la variance
    double sqSum = 0.0;
    for (double payoff : payoffs) {
        sqSum += (payoff - mean) * (payoff - mean);
    }
    double variance = sqSum / (mcParams.numSimulations - 1);
    stdError = std::sqrt(variance / mcParams.numSimulations);
    
    // Actualisation
    return std::exp(-market.r * market.T) * mean;
}

// ========== Calcul du Delta par différences finies ==========
double LookbackOptionPricer::computeDelta() {
    double h = market.S0 * 0.01; // 1% de perturbation
    double originalS = market.S0;
    
    // Prix à S + h
    market.S0 = originalS + h;
    double stdErr;
    double priceUp = computePrice(stdErr);
    
    // Prix à S - h
    market.S0 = originalS - h;
    double priceDown = computePrice(stdErr);
    
    // Restauration
    market.S0 = originalS;
    
    // Différence finie centrée
    return (priceUp - priceDown) / (2.0 * h);
}

// ========== Calcul du Gamma par différences finies ==========
double LookbackOptionPricer::computeGamma() {
    double h = market.S0 * 0.01;
    double originalS = market.S0;
    
    // Prix à S
    double stdErr;
    double priceCenter = computePrice(stdErr);
    
    // Prix à S + h
    market.S0 = originalS + h;
    double priceUp = computePrice(stdErr);
    
    // Prix à S - h
    market.S0 = originalS - h;
    double priceDown = computePrice(stdErr);
    
    // Restauration
    market.S0 = originalS;
    
    // Différence finie seconde
    return (priceUp - 2.0 * priceCenter + priceDown) / (h * h);
}

// ========== Calcul du Theta par différences finies ==========
double LookbackOptionPricer::computeTheta() {
    double h = 1.0 / 365.0; // 1 jour
    double originalT = market.T;
    
    if (market.T <= h) {
        return 0.0; // Proche de la maturité
    }
    
    // Prix à T - h (le temps avance, donc T diminue)
    market.T = originalT - h;
    double stdErr;
    double priceDown = computePrice(stdErr);
    
    // Prix à T
    market.T = originalT;
    double priceCenter = computePrice(stdErr);
    
    // Restauration
    market.T = originalT;
    
    // Theta négatif généralement (décroissance de la valeur temporelle)
    return (priceDown - priceCenter) / h;
}

// ========== Calcul du Rho par différences finies ==========
double LookbackOptionPricer::computeRho() {
    double h = 0.0001; // 1 bp
    double originalR = market.r;
    
    // Prix à r + h
    market.r = originalR + h;
    double stdErr;
    double priceUp = computePrice(stdErr);
    
    // Prix à r - h
    market.r = originalR - h;
    double priceDown = computePrice(stdErr);
    
    // Restauration
    market.r = originalR;
    
    return (priceUp - priceDown) / (2.0 * h);
}

// ========== Calcul du Vega par différences finies ==========
double LookbackOptionPricer::computeVega() {
    double h = 0.001; // 0.1% de volatilité
    double originalSigma = market.sigma;
    
    // Prix à sigma + h
    market.sigma = originalSigma + h;
    double stdErr;
    double priceUp = computePrice(stdErr);
    
    // Prix à sigma - h
    market.sigma = originalSigma - h;
    double priceDown = computePrice(stdErr);
    
    // Restauration
    market.sigma = originalSigma;
    
    return (priceUp - priceDown) / (2.0 * h);
}

// ========== Méthode principale de pricing ==========
OptionResults LookbackOptionPricer::price() {
    OptionResults results;
    
    std::cout << "Calcul du prix..." << std::endl;
    results.price = computePrice(results.stdError);
    
    std::cout << "Calcul du Delta..." << std::endl;
    results.delta = computeDelta();
    
    std::cout << "Calcul du Gamma..." << std::endl;
    results.gamma = computeGamma();
    
    std::cout << "Calcul du Theta..." << std::endl;
    results.theta = computeTheta();
    
    std::cout << "Calcul du Rho..." << std::endl;
    results.rho = computeRho();
    
    std::cout << "Calcul du Vega..." << std::endl;
    results.vega = computeVega();
    
    return results;
}

// ========== Prix en fonction du spot (pour graphique) ==========
std::vector<std::pair<double, double>> LookbackOptionPricer::priceVsSpot(double Smin, double Smax, int numPoints) {
    std::vector<std::pair<double, double>> results;
    results.reserve(numPoints);
    
    double originalS = market.S0;
    double step = (Smax - Smin) / (numPoints - 1);
    
    for (int i = 0; i < numPoints; ++i) {
        double S = Smin + i * step;
        market.S0 = S;
        
        double stdErr;
        double price = computePrice(stdErr);
        results.push_back({S, price});
        
        std::cout << "Point " << (i+1) << "/" << numPoints << " calculé" << std::endl;
    }
    
    market.S0 = originalS;
    return results;
}

// ========== Delta en fonction du spot (pour graphique) ==========
std::vector<std::pair<double, double>> LookbackOptionPricer::deltaVsSpot(double Smin, double Smax, int numPoints) {
    std::vector<std::pair<double, double>> results;
    results.reserve(numPoints);
    
    double originalS = market.S0;
    double step = (Smax - Smin) / (numPoints - 1);
    
    for (int i = 0; i < numPoints; ++i) {
        double S = Smin + i * step;
        market.S0 = S;
        
        double delta = computeDelta();
        results.push_back({S, delta});
        
        std::cout << "Point " << (i+1) << "/" << numPoints << " calculé" << std::endl;
    }
    
    market.S0 = originalS;
    return results;
}

// ========== Fonctions utilitaires ==========
namespace Utils {
    OptionType stringToOptionType(const std::string& type) {
        if (type == "CALL" || type == "Call" || type == "call") {
            return OptionType::CALL;
        } else if (type == "PUT" || type == "Put" || type == "put") {
            return OptionType::PUT;
        } else {
            throw std::invalid_argument("Type d'option invalide. Utilisez CALL ou PUT.");
        }
    }
    
    std::string optionTypeToString(OptionType type) {
        return (type == OptionType::CALL) ? "CALL" : "PUT";
    }
    
    double yearsToMaturity(int days) {
        return days / 365.25;
    }
}
