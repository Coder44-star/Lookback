#ifndef LOOKBACK_OPTION_H
#define LOOKBACK_OPTION_H

#include <vector>
#include <random>
#include <cmath>

struct ModelParams {
    double S0;
    double r;
    double q;
    double sigma;
    double T;
};

struct SimParams {
    int N_sim;
    int N_steps;
};

struct OptionResult {
    double price;
    double std_error;
    double CI_95;
    double computation_time;
};

class LookbackOption {
private:
    ModelParams model;
    std::mt19937 rng;
    std::normal_distribution<double> normal_dist;
    std::uniform_real_distribution<double> uniform_dist;
    
public:
    LookbackOption(const ModelParams& params, unsigned int seed = 42);
    
    OptionResult priceCallStandard(const SimParams& sim_params);
    OptionResult priceCallWithBridge(const SimParams& sim_params);
    OptionResult pricePutStandard(const SimParams& sim_params);
    OptionResult pricePutWithBridge(const SimParams& sim_params);
    
private:
    double barrierHitProbability(double S_prev, double S_next, double barrier, double dt);
};

#endif