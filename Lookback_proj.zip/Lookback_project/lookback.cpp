#include <iostream>
#include <cmath>
#include <random>
#include <vector>
#include <algorithm>
#include <string>
#include <sstream>

using namespace std;

// Générateur de nombres aléatoires
class RandomGenerator {
private:
    mt19937 generator;
    normal_distribution<double> distribution;
    
public:
    RandomGenerator() : generator(random_device{}()), distribution(0.0, 1.0) {}
    
    double getNormal() {
        return distribution(generator);
    }
};

// Classe pour l'option Lookback
class LookbackOption {
private:
    string optionType;  // "call" ou "put"
    double S0;          // Prix initial
    double r;           // Taux sans risque
    double sigma;       // Volatilité
    double T;           // Maturité en années
    int numSimulations; // Nombre de simulations
    int numSteps;       // Nombre de pas de temps
    
    RandomGenerator rng;
    
    // Simuler une trajectoire et retourner le payoff
    double simulatePayoff() {
        double dt = T / numSteps;
        double S = S0;
        double minS = S0;
        double maxS = S0;
        
        // Simulation d'une trajectoire
        for (int i = 0; i < numSteps; i++) {
            double Z = rng.getNormal();
            S = S * exp((r - 0.5 * sigma * sigma) * dt + sigma * sqrt(dt) * Z);
            
            if (S < minS) minS = S;
            if (S > maxS) maxS = S;
        }
        
        // Calcul du payoff selon le type
        if (optionType == "call") {
            return max(0.0, S - minS);
        } else {
            return max(0.0, maxS - S);
        }
    }
    
public:
    LookbackOption(string type, double s0, double rate, double vol, double maturity, 
                   int nSim, int nSteps) 
        : optionType(type), S0(s0), r(rate), sigma(vol), T(maturity),
          numSimulations(nSim), numSteps(nSteps) {}
    
    // Calculer le prix de l'option
    double calculatePrice() {
        double sum = 0.0;
        
        for (int i = 0; i < numSimulations; i++) {
            double payoff = simulatePayoff();
            sum += payoff;
        }
        
        double price = (sum / numSimulations) * exp(-r * T);
        return price;
    }
    
    // Calculer Delta (∂P/∂S) par différences finies
    double calculateDelta(double h = 0.01) {
        double S_original = S0;
        
        // P(S + h)
        S0 = S_original + h * S_original;
        double price_up = calculatePrice();
        
        // P(S - h)
        S0 = S_original - h * S_original;
        double price_down = calculatePrice();
        
        S0 = S_original; // Restaurer
        
        return (price_up - price_down) / (2 * h * S_original);
    }
    
    // Calculer Gamma (∂²P/∂S²) par différences finies
    double calculateGamma(double h = 0.01) {
        double S_original = S0;
        
        // P(S)
        double price_mid = calculatePrice();
        
        // P(S + h)
        S0 = S_original + h * S_original;
        double price_up = calculatePrice();
        
        // P(S - h)
        S0 = S_original - h * S_original;
        double price_down = calculatePrice();
        
        S0 = S_original; // Restaurer
        
        return (price_up - 2 * price_mid + price_down) / pow(h * S_original, 2);
    }
    
    // Calculer Theta (∂P/∂t) - attention: on calcule ∂P/∂T
    double calculateTheta(double h = 0.01) {
        double T_original = T;
        
        // P(T)
        double price_current = calculatePrice();
        
        // P(T - h) - le temps diminue donc on soustrait
        T = T_original - h;
        double price_earlier = calculatePrice();
        
        T = T_original; // Restaurer
        
        // Theta est généralement négatif (décroissance temporelle)
        return (price_earlier - price_current) / h;
    }
    
    // Calculer Rho (∂P/∂r)
    double calculateRho(double h = 0.01) {
        double r_original = r;
        
        // P(r + h)
        r = r_original + h;
        double price_up = calculatePrice();
        
        // P(r - h)
        r = r_original - h;
        double price_down = calculatePrice();
        
        r = r_original; // Restaurer
        
        return (price_up - price_down) / (2 * h);
    }
    
    // Calculer Vega (∂P/∂σ)
    double calculateVega(double h = 0.01) {
        double sigma_original = sigma;
        
        // P(σ + h)
        sigma = sigma_original + h;
        double price_up = calculatePrice();
        
        // P(σ - h)
        sigma = sigma_original - h;
        double price_down = calculatePrice();
        
        sigma = sigma_original; // Restaurer
        
        return (price_up - price_down) / (2 * h);
    }
    
    // Calculer le prix pour différentes valeurs de S (pour graphique)
    vector<pair<double, double>> calculatePriceVsSpot(double S_min, double S_max, int numPoints) {
        vector<pair<double, double>> results;
        double S_original = S0;
        
        double step = (S_max - S_min) / (numPoints - 1);
        
        for (int i = 0; i < numPoints; i++) {
            S0 = S_min + i * step;
            double price = calculatePrice();
            results.push_back(make_pair(S0, price));
        }
        
        S0 = S_original; // Restaurer
        return results;
    }
    
    // Calculer Delta pour différentes valeurs de S (pour graphique)
    vector<pair<double, double>> calculateDeltaVsSpot(double S_min, double S_max, int numPoints) {
        vector<pair<double, double>> results;
        double S_original = S0;
        
        double step = (S_max - S_min) / (numPoints - 1);
        
        for (int i = 0; i < numPoints; i++) {
            S0 = S_min + i * step;
            double delta = calculateDelta();
            results.push_back(make_pair(S0, delta));
        }
        
        S0 = S_original; // Restaurer
        return results;
    }
};

// Fonction principale pour être appelée depuis Excel/VBA
extern "C" {
    // Calculer tous les Greeks et le prix
    __declspec(dllexport) void __stdcall CalculateLookback(
        const char* optionType,
        double S0,
        double r,
        double sigma,
        double T,
        int numSimulations,
        int numSteps,
        double* price,
        double* delta,
        double* gamma,
        double* theta,
        double* rho,
        double* vega
    ) {
        LookbackOption option(optionType, S0, r, sigma, T, numSimulations, numSteps);
        
        *price = option.calculatePrice();
        *delta = option.calculateDelta();
        *gamma = option.calculateGamma();
        *theta = option.calculateTheta();
        *rho = option.calculateRho();
        *vega = option.calculateVega();
    }
    
    // Calculer prix pour un point spécifique (pour graphiques)
    __declspec(dllexport) double __stdcall CalculatePriceAtSpot(
        const char* optionType,
        double S0,
        double r,
        double sigma,
        double T,
        int numSimulations,
        int numSteps
    ) {
        LookbackOption option(optionType, S0, r, sigma, T, numSimulations, numSteps);
        return option.calculatePrice();
    }
    
    // Calculer delta pour un point spécifique (pour graphiques)
    __declspec(dllexport) double __stdcall CalculateDeltaAtSpot(
        const char* optionType,
        double S0,
        double r,
        double sigma,
        double T,
        int numSimulations,
        int numSteps
    ) {
        LookbackOption option(optionType, S0, r, sigma, T, numSimulations, numSteps);
        return option.calculateDelta();
    }
}

// Fonction main pour tester en ligne de commande
int main() {
    cout << "=== Calculateur d'Options Lookback ===" << endl << endl;
    
    // Paramètres par défaut
    string optionType = "call";
    double S0 = 100.0;
    double r = 0.05;
    double sigma = 0.2;
    double T = 1.0;
    int numSimulations = 100000;
    int numSteps = 252;
    
    cout << "Type d'option: " << optionType << endl;
    cout << "Prix initial: " << S0 << endl;
    cout << "Taux sans risque: " << r << endl;
    cout << "Volatilité: " << sigma << endl;
    cout << "Maturité (années): " << T << endl;
    cout << "Nombre de simulations: " << numSimulations << endl;
    cout << "Nombre de pas: " << numSteps << endl << endl;
    
    LookbackOption option(optionType, S0, r, sigma, T, numSimulations, numSteps);
    
    cout << "Calcul en cours..." << endl << endl;
    
    double price = option.calculatePrice();
    cout << "Prix de l'option: " << price << endl;
    
    double delta = option.calculateDelta();
    cout << "Delta: " << delta << endl;
    
    double gamma = option.calculateGamma();
    cout << "Gamma: " << gamma << endl;
    
    double theta = option.calculateTheta();
    cout << "Theta: " << theta << endl;
    
    double rho = option.calculateRho();
    cout << "Rho: " << rho << endl;
    
    double vega = option.calculateVega();
    cout << "Vega: " << vega << endl;
    
    return 0;
}