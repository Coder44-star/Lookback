#include "lookback_option.h"
#include <chrono>
#include <algorithm>

LookbackOption::LookbackOption(const ModelParams& params, unsigned int seed)
    : model(params), rng(seed), normal_dist(0.0, 1.0), uniform_dist(0.0, 1.0) {
}

double LookbackOption::barrierHitProbability(double S_prev, double S_next, double barrier, double dt) {
    if (S_prev <= barrier || S_next <= barrier) {
        return 1.0;
    }
    
    double log_ratio_1 = std::log(S_prev / barrier);
    double log_ratio_2 = std::log(S_next / barrier);
    
    return std::exp(-2.0 * log_ratio_1 * log_ratio_2 / (model.sigma * model.sigma * dt));
}

OptionResult LookbackOption::priceCallStandard(const SimParams& sim_params) {
    auto start = std::chrono::high_resolution_clock::now();
    
    double dt = model.T / sim_params.N_steps;
    double drift = (model.r - model.q - 0.5 * model.sigma * model.sigma) * dt;
    double diffusion = model.sigma * std::sqrt(dt);
    double discount = std::exp(-model.r * model.T);
    
    std::vector<double> payoffs(sim_params.N_sim);
    
    for (int i = 0; i < sim_params.N_sim; ++i) {
        double S = model.S0;
        double S_min = model.S0;
        
        for (int j = 0; j < sim_params.N_steps; ++j) {
            double Z = normal_dist(rng);
            S *= std::exp(drift + diffusion * Z);
            S_min = std::min(S_min, S);
        }
        
        payoffs[i] = std::max(S - S_min, 0.0);
    }
    
    double sum = 0.0;
    double sum_sq = 0.0;
    for (double p : payoffs) {
        sum += p;
        sum_sq += p * p;
    }
    
    double mean = sum / sim_params.N_sim;
    double variance = (sum_sq / sim_params.N_sim) - (mean * mean);
    double std_dev = std::sqrt(variance);
    
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    OptionResult result;
    result.price = discount * mean;
    result.std_error = discount * std_dev / std::sqrt(sim_params.N_sim);
    result.CI_95 = 1.96 * result.std_error;
    result.computation_time = elapsed.count();
    
    return result;
}

OptionResult LookbackOption::priceCallWithBridge(const SimParams& sim_params) {
    auto start = std::chrono::high_resolution_clock::now();
    
    double dt = model.T / sim_params.N_steps;
    double drift = (model.r - model.q - 0.5 * model.sigma * model.sigma) * dt;
    double diffusion = model.sigma * std::sqrt(dt);
    double discount = std::exp(-model.r * model.T);
    
    std::vector<double> payoffs(sim_params.N_sim);
    
    for (int i = 0; i < sim_params.N_sim; ++i) {
        std::vector<double> S_path(sim_params.N_steps + 1);
        S_path[0] = model.S0;
        
        for (int j = 0; j < sim_params.N_steps; ++j) {
            double Z = normal_dist(rng);
            S_path[j + 1] = S_path[j] * std::exp(drift + diffusion * Z);
        }
        
        double S_min = S_path[0];
        for (int j = 0; j < sim_params.N_steps; ++j) {
            double S_prev = S_path[j];
            double S_next = S_path[j + 1];
            double S_min_interval = std::min(S_prev, S_next);
            
            if (S_prev > S_min && S_next > S_min) {
                double prob = barrierHitProbability(S_prev, S_next, S_min, dt);
                double U = uniform_dist(rng);
                
                if (U < prob) {
                    double alpha = uniform_dist(rng);
                    double est = S_min * std::exp(-model.sigma * std::sqrt(dt * alpha) * std::abs(normal_dist(rng)));
                    S_min = std::min(S_min, est);
                } else {
                    S_min = std::min(S_min, S_min_interval);
                }
            } else {
                S_min = std::min(S_min, S_min_interval);
            }
        }
        
        payoffs[i] = std::max(S_path.back() - S_min, 0.0);
    }
    
    double sum = 0.0;
    double sum_sq = 0.0;
    for (double p : payoffs) {
        sum += p;
        sum_sq += p * p;
    }
    
    double mean = sum / sim_params.N_sim;
    double variance = (sum_sq / sim_params.N_sim) - (mean * mean);
    double std_dev = std::sqrt(variance);
    
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    OptionResult result;
    result.price = discount * mean;
    result.std_error = discount * std_dev / std::sqrt(sim_params.N_sim);
    result.CI_95 = 1.96 * result.std_error;
    result.computation_time = elapsed.count();
    
    return result;
}

OptionResult LookbackOption::pricePutStandard(const SimParams& sim_params) {
    auto start = std::chrono::high_resolution_clock::now();
    
    double dt = model.T / sim_params.N_steps;
    double drift = (model.r - model.q - 0.5 * model.sigma * model.sigma) * dt;
    double diffusion = model.sigma * std::sqrt(dt);
    double discount = std::exp(-model.r * model.T);
    
    std::vector<double> payoffs(sim_params.N_sim);
    
    for (int i = 0; i < sim_params.N_sim; ++i) {
        double S = model.S0;
        double S_max = model.S0;
        
        for (int j = 0; j < sim_params.N_steps; ++j) {
            double Z = normal_dist(rng);
            S *= std::exp(drift + diffusion * Z);
            S_max = std::max(S_max, S);
        }
        
        payoffs[i] = std::max(S_max - S, 0.0);
    }
    
    double sum = 0.0;
    double sum_sq = 0.0;
    for (double p : payoffs) {
        sum += p;
        sum_sq += p * p;
    }
    
    double mean = sum / sim_params.N_sim;
    double variance = (sum_sq / sim_params.N_sim) - (mean * mean);
    double std_dev = std::sqrt(variance);
    
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    OptionResult result;
    result.price = discount * mean;
    result.std_error = discount * std_dev / std::sqrt(sim_params.N_sim);
    result.CI_95 = 1.96 * result.std_error;
    result.computation_time = elapsed.count();
    
    return result;
}

OptionResult LookbackOption::pricePutWithBridge(const SimParams& sim_params) {
    auto start = std::chrono::high_resolution_clock::now();
    
    double dt = model.T / sim_params.N_steps;
    double drift = (model.r - model.q - 0.5 * model.sigma * model.sigma) * dt;
    double diffusion = model.sigma * std::sqrt(dt);
    double discount = std::exp(-model.r * model.T);
    
    std::vector<double> payoffs(sim_params.N_sim);
    
    for (int i = 0; i < sim_params.N_sim; ++i) {
        std::vector<double> S_path(sim_params.N_steps + 1);
        S_path[0] = model.S0;
        
        for (int j = 0; j < sim_params.N_steps; ++j) {
            double Z = normal_dist(rng);
            S_path[j + 1] = S_path[j] * std::exp(drift + diffusion * Z);
        }
        
        double S_max = S_path[0];
        for (int j = 0; j < sim_params.N_steps; ++j) {
            double S_prev = S_path[j];
            double S_next = S_path[j + 1];
            double S_max_interval = std::max(S_prev, S_next);
            
            if (S_prev < S_max && S_next < S_max) {
                double prob = barrierHitProbability(1.0/S_prev, 1.0/S_next, 1.0/S_max, dt);
                double U = uniform_dist(rng);
                
                if (U < prob) {
                    double alpha = uniform_dist(rng);
                    double est = S_max * std::exp(model.sigma * std::sqrt(dt * alpha) * std::abs(normal_dist(rng)));
                    S_max = std::max(S_max, est);
                } else {
                    S_max = std::max(S_max, S_max_interval);
                }
            } else {
                S_max = std::max(S_max, S_max_interval);
            }
        }
        
        payoffs[i] = std::max(S_max - S_path.back(), 0.0);
    }
    
    double sum = 0.0;
    double sum_sq = 0.0;
    for (double p : payoffs) {
        sum += p;
        sum_sq += p * p;
    }
    
    double mean = sum / sim_params.N_sim;
    double variance = (sum_sq / sim_params.N_sim) - (mean * mean);
    double std_dev = std::sqrt(variance);
    
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    OptionResult result;
    result.price = discount * mean;
    result.std_error = discount * std_dev / std::sqrt(sim_params.N_sim);
    result.CI_95 = 1.96 * result.std_error;
    result.computation_time = elapsed.count();
    
    return result;
}