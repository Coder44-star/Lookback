#include "lookback_option.h"
#include <fstream>
#include <iostream>
#include <iomanip>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <input_file> <output_file>" << std::endl;
        return 1;
    }
    
    std::string inputFile = argv[1];
    std::string outputFile = argv[2];
    
    try {
        std::ifstream inFile(inputFile);
        if (!inFile.is_open()) {
            std::cerr << "ERROR: Cannot open input file" << std::endl;
            return 1;
        }
        
        ModelParams model;
        SimParams sim;
        std::string optionType;
        int useBridge;
        
        inFile >> model.S0 >> model.r >> model.q >> model.sigma >> model.T;
        inFile >> sim.N_sim >> sim.N_steps;
        inFile >> optionType >> useBridge;
        inFile.close();
        
        LookbackOption option(model);
        OptionResult result;
        
        if (optionType == "call") {
            result = useBridge ? option.priceCallWithBridge(sim) : option.priceCallStandard(sim);
        } else {
            result = useBridge ? option.pricePutWithBridge(sim) : option.pricePutStandard(sim);
        }
        
        std::ofstream outFile(outputFile);
        if (!outFile.is_open()) {
            std::cerr << "ERROR: Cannot create output file" << std::endl;
            return 1;
        }
        
        outFile << std::fixed << std::setprecision(8);
        outFile << result.price << std::endl;
        outFile << result.std_error << std::endl;
        outFile << result.CI_95 << std::endl;
        outFile << result.computation_time << std::endl;
        outFile.close();
        
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "EXCEPTION: " << e.what() << std::endl;
        return 1;
    }
}
